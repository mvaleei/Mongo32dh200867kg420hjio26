import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('avvio');

  nome: string = "Paolo Rossi";

  metodo(): void {
    alert("Sono un metodo chiamato dalla grafica")
  }


  spesa: Array<string> = [
    "Frutta", "Verdura", "Pesce", "Carne"
  ]


  aggiungi(): void {
    this.spesa.push("Biscotti");
  }

}
