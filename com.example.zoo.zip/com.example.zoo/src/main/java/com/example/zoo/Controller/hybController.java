package com.example.zoo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.zoo.models.cane;
import com.example.zoo.services.caneHyb;




@Controller
@RequestMapping("/hyb/*")
public class hybController {
	
	 @Autowired
	 public caneHyb caneHybernate;
	 
	 @RequestMapping("leggi")
	 public String leggihyb(Model modello) {
		 
		 List<cane> letti = caneHybernate.getallCani();
		 modello.addAttribute("torna",letti);
		 
		 return "lista";		 
	 }
	 
	 
}
