package com.example.zoo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.zoo.models.cane;


//definisco il repository per utiizzare hybernate
@Repository
public interface CaneRepository extends JpaRepository<cane, Long> {

}
