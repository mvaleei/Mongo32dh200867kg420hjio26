package com.example.zoo.services;

import com.example.zoo.repository.CaneRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.zoo.models.cane;

import java.util.List;
import java.util.Optional;



@Service
public class caneHyb {
	
	
	@Autowired
	private CaneRepository dogRepository;
	
	
	
	//per leggere tutti i cani nel db
	public List<cane> getallCani(){
		return dogRepository.findAll();
	}
	
	
	public void addCane(cane aggiungi) {
		dogRepository.save(aggiungi);
	}
	
	public Optional<cane> leggiCane(Long id){
		Optional<cane> dog =dogRepository.findById(id);
		
		return dog;
		
	}
	

}
