package com.example.zoo.Controller;
//controller che si collega  al db, in modo classico
//istruzioni sql

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.http.HttpServletResponse;




import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.SQLException;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.zoo.models.cane;

@Controller
@RequestMapping("/caniDB/*")
public class CanidbController {
	
	@RequestMapping("/")
	//@ResponseBody
	public String index() {
		return "cani/Index";
	}
	
	
	@RequestMapping("listato")
	public String listato(Model ListaCani) {
		
		ArrayList<cane> canile= new ArrayList<cane>();
		//collego al db
		//andrebbe fatto com il Data Access Layer
		try
		{					
			Class.forName("com.mysql.jdbc.Driver");
	
			Connection	conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/springdb?user=root&password=Coletti1");
			
			Statement st;		
			ResultSet rs;		
			
			st=conn.createStatement();
			rs=st.executeQuery("select * from cani");
			
			
			
			while (rs.next()){
				canile.add(new cane (rs.getLong("id"),rs.getString("nome"),rs.getString("razza")));
			}
			
			System.out.println(canile.size());
			
		}
		catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		catch (SQLException erroresql)
		{
			System.out.println(erroresql);
			
		}	
		
		ListaCani.addAttribute("torna",canile);
		
		
		return "cani/listato";
	}
	
	//schermata per registrare il nuovo cane
	@RequestMapping("inserisci")
	//@ResponseBody
	public String addCane() {
		return "cani/inserisci";
	}
	
	
	//attività di registrazione sul database  (nuovo cane)
	@PostMapping("registra")	
	public String RegistraCane(@ModelAttribute cane dog,HttpServletResponse httpResponsemio) throws Exception {
		
				
		System.out.println(dog.getNome());
		
		//inserisco il nuovo cane nel db
		//->
		try
		{					
			Class.forName("com.mysql.jdbc.Driver");
	
			Connection	conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/springdb?user=root&password=Coletti1");
			
			String inviare="insert into cani (nome,razza) values ('" + dog.getNome() +"' , '"+ dog.getRazza() + "')";
			
			
			PreparedStatement p= conn.prepareStatement(inviare);		
			
			p.execute();
			
		
		}
		catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		catch (SQLException erroresql)
		{
			System.out.println(erroresql);
			
		}	
		
		
		
		//<-
		
		
		
		
		httpResponsemio.sendRedirect("listato");
		

		
		return null;
	}
	

}
