package com.example.zoo.Controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.zoo.models.cane;

@Controller
public class HomeController {
	
	//singleton  istanziare una classe una sola volta
	//invio testo 
	@RequestMapping("/")
	@ResponseBody
	public String index()
	{
		return "Home page - testo semplice";
	}
	
	
	//ricevo querystring in chiamata da qualsiasi client
	//e li retituisco in un testo semplice
	@RequestMapping("/riceviquerystring")
	@ResponseBody
	public String risposta(@RequestParam String nomeRicevuto,int anniRicevuti) {
		return "Ho ricevuto il nome" + nomeRicevuto + " e ho scoperto che hai anni" + anniRicevuti;
	}
	
	
	//ricevo regole di routing in chiamata da qualsiasi client
	//e li retituisco in un testo semplice
	@RequestMapping("/riceviregola/{nomeRicevuto}/{anniRicevuti}")
	@ResponseBody
	public String rispostaregola(@PathVariable String nomeRicevuto ,@PathVariable  int anniRicevuti) {
		return "Ho ricevuto il nome" + nomeRicevuto + " e ho scoperto che hai anni" + anniRicevuti;
	}
	
	
	
	
	//invio pagina realizzata in HTML
	//importare il thymeleaf
	@RequestMapping("/prima")
	public String primapagina() {
		return "prima";
	}
	

	//torno i dati nelle pagine html  --SEMPLICE STRINGA
	//importare il Model
	@RequestMapping("/tornadato")
	public String tornadati(Model Modello) {
		String datoRestituito="Sono una stringa che torna dal server";
		Modello.addAttribute("torna" ,datoRestituito);
		return "tornata";				
	}
	
	
	//torno i dati (oggetto cane) nelle pagine html  --oggetto cane
	//importare il Model
	@RequestMapping("/tornadogstatico")
	public String tornaoggetto(Model Modello) {
		cane dog = new cane(1,"Bassotto","Bobby");
		System.out.println(dog.getNome());
		
		Modello.addAttribute("torna" ,dog);
		return "vedicane";				
	}
	
	//torno i dati della lista nella pagina html  --oggetto List
	//importare il Model
	@RequestMapping("/tornaarray")
	public String tornalista(Model Modello) {
		
		
		List<cane> canile= new ArrayList<>(Arrays.asList(
				new cane(1,"Bobby","Bassotto"),
				new cane(2,"Fido","Lupo"),
				new cane(3,"Rocky","Rotwailer"),
				new cane(4,"Rambo","Bastardino")
				));
		
		
		
		
		
		Modello.addAttribute("torna" ,canile);
		return "lista";				
	}
	
	
	

}
