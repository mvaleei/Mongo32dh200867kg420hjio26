package com.example.zoo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GenerationType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="cani")
public class cane {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ID;
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public String getRazza() {
		return razza;
	}
	public void setRazza(String razza) {
		this.razza = razza;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	private String razza;
	private String nome;
	
	
	public cane() {
		
	}
	
	public cane (long id,String Razza,String Nome)
	{
		this.ID=id;
		this.nome=Nome;
		this.razza=Razza;
	}
}
