
import './App.css'

import { Arrow } from './Componenti/Freccia'

import { Parametri } from './Componenti/Parametri'

import { Listato } from './Componenti/Listato'

export function App() {

  const citta = "Palermo"

  return (
    <div>
      <ul>
        <li><label htmlFor="">Sono un listItem</label></li>
        <li><label htmlFor="">Sono un listItem</label></li>
        <li><label htmlFor="">Sono un listItem</label></li>
      </ul>
      <CompoMio></CompoMio>
      <Arrow></Arrow>
      <Parametri citta='Caserta' lavoro='Impiegato'></Parametri>
      <Parametri lavoro={citta} citta='Savona'></Parametri>
      <Parametri lavoro='Operaio' citta='Milano'></Parametri>

      <Listato></Listato>


    </div>
  )
}


export function CompoMio() {
  return (
    <p>Ciao</p>
  )
}

//export default App
