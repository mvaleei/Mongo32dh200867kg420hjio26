

const spesa: Array<string> = [
    "Carne", "Verdura", "Frutta", "Latte"
]

export const Listato = () => {


    return (
        <div>
            <h3>Componente per gli array</h3>

            {
                spesa.map(
                    (nomeProdotto: string) => {
                        return (
                            <div>
                                <label htmlFor="">{nomeProdotto}</label>
                            </div>
                        )

                    }
                )
            }



        </div>
    )

}