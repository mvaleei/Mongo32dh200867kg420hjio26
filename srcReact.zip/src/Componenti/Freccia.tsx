import { useState } from "react"


const LayOutMio = {
    backgroundColor: "yellow",
    width: "80%",
    align: "center"
}

const maschera = {
    backgroundColor: "cyan",
    width: "60%",
    align: "center"
}

/*   gli state, vanno dichiarati INERNAMENTE al componente
const [
    nomedelloggettodatenereinmemoria,
    nomedellafunzioneperassegnarevaloriallostate
] =useState<string>("valore di default")
 */

//const nome = "Mario Rossi"

export const Arrow = () => {

    const [
        nome,
        setNome
    ] = useState<string>("Mario Rossi")   //hook 

    const [anni, setAnni] = useState<number>(0);



    /*
    const leggi = () => {
        alert("Mi preparo a leggere i dati");
    }
        */

    return (
        <div style={LayOutMio}>
            <ol>
                <li><label htmlFor="">Sono il componente arrow</label></li>
                <li><label htmlFor="">Sono il componente arrow</label></li>
                <li><label htmlFor="">Sono il componente arrow</label></li>
                <li><label htmlFor="">Sono il componente arrow</label></li>
            </ol>
            <div>
                <label htmlFor="">Il tuo nome è:{nome}</label>
            </div>
            <div style={maschera}>
                <label htmlFor="">Inserisci il tuo nome</label>
                <input
                    type="text"
                    onChange={
                        (nomeVirtualePerPuntareAlValoreDigitato: any) => {
                            //setNome("Giorgio Verdi")
                            setNome(nomeVirtualePerPuntareAlValoreDigitato.target.value)
                            console.log(nome);
                        }
                    }
                />
                <br />
                <label htmlFor="">Inserisci i tuoi anni</label>
                <input
                    type="number"
                    onChange={
                        (anniInseriti: any) => {
                            setAnni(anniInseriti.target.value);

                        }
                    }
                />
                <div>
                    Gli anni inseriti sono:{anni}
                </div>
                <button
                    //onClick={leggi}
                    onClick={
                        () => {
                            alert("Sono una arrow function. Il valore di nome è " + nome)
                        }
                    }
                >Clicca per conoscere i dati</button>

            </div>
        </div>
    )
}

