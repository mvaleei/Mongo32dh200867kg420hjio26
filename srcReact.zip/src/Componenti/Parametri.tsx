

const marrone = {
    backgroundColor: "brown",
    width: "80%",
    color: "white"
}


interface oggettoRicezione {
    lavoro: string,
    citta: string
}

export const Parametri = ({ lavoro, citta }: oggettoRicezione) => {
    return (
        <div style={marrone}>
            <label htmlFor="">Valore ricevuto dal componente padre: {lavoro}</label> -
            <label htmlFor="">La città dichiarata è: {citta}</label>
        </div>
    )
}